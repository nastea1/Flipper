=== .\legacy ===
This folder contains the legacy support module for Espressif Flash Manager (N2D22), the esptool.exe
is v3.0 compiled using PyInstaller (the exact same binary that shipped with n2d 2021). 

Legacy (Portable) mode can be enabled at startup using the --portable flag. See Wiki for full details on the software.
